# Cashere™ Monorepo (MVP v0.5)

**New in v0.5**
- Risk & Trust scoring
- Moderation queue
- Geofenced zones (ATL) + nearest assignment
- Cross‑post analytics
- Admin console `/admin`

Includes v0.4: auto‑accept timers, buyer inspection, title viewer + mock anchor, payouts, TTLock stub, disputes UI.
