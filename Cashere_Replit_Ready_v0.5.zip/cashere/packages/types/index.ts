export type ULID = string;
export type Condition = "new" | "like_new" | "good" | "fair" | "poor";

export interface ItemDTO { title: string; description: string; category: string; condition: Condition; media: string[]; seller_id?: string; }
export interface Item extends ItemDTO { id: string; seller_id: string; status: "draft" | "listed" | "sold"; }
export interface Listing { id: string; item_id: string; title?: string; description?: string; category?: string; price_cents: number; status: "pending_review" | "active" | "rejected" | "pending_sold" | "sold"; cash_tag_id?: string; seller_id?: string; }

export interface Order {
  id: string;
  listing_id: string;
  buyer_id?: string;
  seller_id?: string;
  payment_intent_id?: string;
  status: "auth_hold" | "captured" | "refunded" | "canceled" | "disputed";
  reason?: string;
  created_at: string;
  picked_up_at?: string;
  inspection_done?: boolean;
  inspection_video_url?: string;
  accept_deadline?: string;
}

export interface Zone { id: string; name: string; lat: number; lng: number; radius_km: number; }
