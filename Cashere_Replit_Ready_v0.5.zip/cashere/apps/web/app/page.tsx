"use client";
import { useEffect, useState } from "react";
import { Button, Card, Tag, Modal, Table } from "@cashere/ui";
import useSWR from "swr";

const api = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";
const fetcher = (url: string) => fetch(url).then(r=>r.json());

export default function Home() {
  const { data: listings, mutate: reloadListings } = useSWR(api + "/v1/listings", fetcher);
  const { data: orders, mutate: reloadOrders } = useSWR(api + "/v1/orders?limit=20", fetcher);
  const { data: anchor, mutate: reloadAnchor } = useSWR(api + "/v1/cashtag", fetcher);

  const [titleOpen, setTitleOpen] = useState(false);
  const [titleData, setTitleData] = useState<any>(null);

  useEffect(() => { reloadAnchor(); }, []);

  async function viewTitle(titleId: string) {
    const data = await fetch(api + "/v1/cashtag/" + titleId).then(r=>r.json());
    setTitleData({ ...data, anchor });
    setTitleOpen(true);
  }

  return (
    <main style={{ maxWidth: 1200, margin: "0 auto", padding: 24 }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <h1>Don&apos;t get me beat up. Ditch the meetup.</h1>
        <div style={{ display:'flex', gap:12 }}>
          <a href="/admin"><Button variant="secondary">Admin</Button></a>
          <AuthWidget />
        </div>
      </header>

      <section style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom: 24 }}>
        <Card title="Quick actions">
          <div style={{ display:'flex', gap:12, marginTop:12 }}>
            <CreateSampleListing onDone={reloadListings} />
            <Button variant="secondary" onClick={() => { reloadListings(); reloadOrders(); }}>Refresh</Button>
          </div>
        </Card>
        <PayoutsCard />
      </section>

      <section style={{ marginBottom: 24 }}>
        <h3>Listings</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(280px,1fr))", gap: 16 }}>
          {(listings || []).map((l: any) => (
            <Card key={l.id}>
              <b>{l.title || "Untitled"}</b>{" "}
              <Tag tone={l.status==='active' ? 'success' : l.status==='rejected' ? 'danger':'warning'}>{l.status}</Tag>
              <div style={{ opacity: 0.7, margin: "6px 0" }}>{l.description || "No description"}</div>
              <div>${(l.price_cents/100 || 0).toFixed(2)}</div>
              <div style={{ display:'flex', gap:8, marginTop:8, flexWrap:'wrap' }}>
                <Button onClick={async () => {
                  const res = await fetch(api + "/v1/orders", { method:"POST", headers:{ "Content-Type": "application/json" }, body: JSON.stringify({ listing_id: l.id, payment_method_id: "pm_mock" })});
                  const order = await res.json();
                  const r = await fetch(api + "/v1/locker/reserve", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ order_id: order.id })});
                  const reservation = await r.json();
                  alert("Reserved locker in zone " + reservation.zone_id + ". Token: " + reservation.token + "\nAuto-opened (dev).");
                  reloadOrders();
                }}>Buy (demo)</Button>
                {l.cash_tag_id ? <Button variant="secondary" onClick={() => viewTitle(l.cash_tag_id)}>View Title</Button> : null}
                <ShareLink listingId={l.id} />
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <h3>Orders</h3>
        <div style={{ display:'grid', gap:12 }}>
          {(orders || []).map((o: any) => (
            <Card key={o.id}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <div>
                  <b>Order {o.id.slice(0,8)}</b>{" "}
                  <Tag tone={o.status==='captured'?'success':o.status==='disputed'?'danger':'default'}>{o.status}</Tag>
                  {o.reason ? <span style={{ marginLeft:8, opacity:0.7 }}>({o.reason})</span> : null}
                  <div style={{ fontSize:12, opacity:0.7, marginTop:4 }}>
                    {o.picked_up_at ? <>Picked up: {new Date(o.picked_up_at).toLocaleTimeString()} • </> : null}
                    {o.accept_deadline ? <>Auto-accept: {new Date(o.accept_deadline).toLocaleTimeString()}</> : null}
                  </div>
                  <div style={{ fontSize:12, opacity:0.8, marginTop:4 }}>
                    Inspection: {o.inspection_done ? "✅ done" : "— not yet"}
                    {o.inspection_video_url ? <> • video: <a href={o.inspection_video_url} target="_blank">link</a></> : null}
                  </div>
                </div>
                <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                  <Button variant="secondary" onClick={async () => {
                    const url = prompt("Paste inspection video URL (optional):", "https://example.com/demo-inspection.mp4");
                    await fetch(api + "/v1/evidence/inspection", { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ order_id: o.id, video_url: url || undefined }) });
                    reloadOrders();
                  }}>Record Inspection</Button>
                  <Button variant="success" onClick={async () => {
                    await fetch(api + "/v1/orders/"+o.id+"/accept", { method:'POST' });
                    reloadOrders();
                  }}>Accept</Button>
                  <Button variant="danger" onClick={async () => {
                    const reason = prompt("Reason for dispute? e.g., 'Not as described'");
                    if (!reason) return;
                    await fetch(api + "/v1/orders/"+o.id+"/dispute", { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ reason }) });
                    reloadOrders();
                  }}>Dispute</Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      <Modal open={titleOpen} onClose={()=>setTitleOpen(false)}>
        {titleData ? <TitleViewer data={titleData} /> : null}
      </Modal>
    </main>
  );
}

function AuthWidget() {
  const pk = process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY;
  if (!pk) return <span style={{ opacity: 0.7 }}>Guest mode</span>;
  const { useUser, SignInButton, UserButton } = require("@clerk/clerk-react");
  const { isSignedIn } = useUser();
  return isSignedIn ? <UserButton afterSignOutUrl="/" /> : <SignInButton />;
}

function CreateSampleListing({ onDone }: { onDone: () => void }) {
  return <Button onClick={async () => {
    const res1 = await fetch(api + "/v1/items", { method:"POST", headers:{ "Content-Type":"application/json", "X-Device-Id":"dev1" }, body: JSON.stringify({ title:"iPhone 12", description:"Blue, 128GB", category:"phones", condition:"good", media:[], seller_id:'seller-demo' }) });
    const item = await res1.json();
    const res2 = await fetch(api + "/v1/listings", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ item_id: item.id, title: item.title, description: item.description, category:"phones", price_cents: 25000, seller_id:'seller-demo' }) });
    await res2.json();
    onDone();
  }}>Create sample listing</Button>;
}

function PayoutsCard() {
  return (
    <Card title="Seller payouts (Stripe Connect)">
      <p style={{ opacity:0.75 }}>Express onboarding link (mocked if no Stripe key).</p>
      <div style={{ display:'flex', gap:8 }}>
        <Button onClick={async () => {
          const r = await fetch(api + "/v1/payouts/onboarding", { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ user_id:'seller-demo', email:'seller@cashere.test' }) });
          const j = await r.json();
          if (j.mock) alert("Mock onboarding link (dev): " + j.onboarding_url);
          else window.open(j.onboarding_url, "_blank");
        }}>Start onboarding</Button>
        <Button variant="secondary" onClick={async () => {
          const r = await fetch(api + "/v1/payouts/account/seller-demo");
          const j = await r.json();
          alert(JSON.stringify(j, null, 2));
        }}>Check status</Button>
      </div>
    </Card>
  );
}

function ShareLink({ listingId }: { listingId: string }) {
  const [stats, setStats] = useState<any>(null);
  return (
    <>
      <Button variant="secondary" onClick={async () => {
        const res = await fetch(api + "/v1/track/link?listing_id=" + listingId + "&source=fb");
        const link = await res.json();
        navigator.clipboard.writeText(link.url);
        alert("Share link copied: " + link.url);
      }}>Copy FB Link</Button>
      <Button variant="secondary" onClick={async () => {
        const res = await fetch(api + "/v1/track/stats/" + listingId);
        setStats(await res.json());
      }}>View Stats</Button>
      {stats ? <div style={{ width:'100%' }}>
        <Table columns={["Token","Source","Clicks"]} rows={(stats.links||[]).map((l:any)=>[l.token, l.source, String(l.clicks)])} />
        <div style={{ fontSize:12, opacity:0.7, marginTop:4 }}>Total clicks: {stats.total_clicks}</div>
      </div> : null}
    </>
  );
}

function TitleViewer({ data }: { data: any }) {
  return (
    <div>
      <h3>Cash Tag — Title Snapshot</h3>
      <p style={{ fontSize:14 }}><b>Title ID:</b> {data.title_id}</p>
      <p style={{ fontSize:14 }}><b>Snapshot hash:</b> {data.snapshot_hash.slice(0,16)}…</p>
      <p style={{ fontSize:14 }}><b>Created:</b> {new Date(data.created_at).toLocaleString()}</p>
      {data.anchor ? (
        <div style={{ marginTop:8, paddingTop:8, borderTop:'1px solid #eee' }}>
          <h4>Anchor (mock demo)</h4>
          <p style={{ fontSize:14 }}><b>Merkle root:</b> {data.anchor.merkle_root.slice(0,16)}…</p>
          <p style={{ fontSize:14 }}><b>Anchored at:</b> {new Date(data.anchor.anchored_at).toLocaleString()}</p>
          <p style={{ fontSize:14 }}><b>Tx ID:</b> {data.anchor.tx_id}</p>
          <p style={{ fontSize:12, opacity:0.7 }}>Count included: {data.anchor.count}</p>
        </div>
      ) : null}
      <div style={{ display:'flex', justifyContent:'flex-end', marginTop:16 }}>
        <Button onClick={()=>location.reload()}>Close</Button>
      </div>
    </div>
  );
}
